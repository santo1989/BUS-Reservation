<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.master','data' => []]); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> 
        Details
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadCrumb', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.breadcrumb','data' => []]); ?>
<?php $component->withName('backend.layouts.elements.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('pageHeader', null, []); ?>  Events  <?php $__env->endSlot(); ?>

            <li class="breadcrumb-item"><a href="<?php echo e(route('events.index')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Add New</li>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
           Events Details <a class="btn btn-sm btn-info" href="<?php echo e(route('events.index')); ?>">List</a>
        </div>
        <div class="card-body">
            
           
                <p>Image : <h3>
                    <img src="<?php echo e(asset('/images/events/'.$event_show->images)); ?>" alt=""
                                class="img" style="height: 250px; width:250px;">
                </h3></p>
                <p>Name : <h3><?php echo e($event_show->name); ?></h3></p>
                <p>Details :  <h3><?php echo e($event_show->details); ?></h3></p>   

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/backend/events/show.blade.php ENDPATH**/ ?>