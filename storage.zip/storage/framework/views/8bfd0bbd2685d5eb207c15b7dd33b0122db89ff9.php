


<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; <?php echo e(now()->year); ?></div>
            <div>
                <a href="https:breakitsolution.com" target="blank">Develop by Break-IT</a> &nbsp; &nbsp; &nbsp; &nbsp;
                
                <a href="https://wa.me/8801714389465" target="blank">Chat on WhatsApp</a>


            </div>
        </div>
    </div>
</footer><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/components/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>