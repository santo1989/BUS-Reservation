<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.master','data' => []]); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> 
        Driver
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadCrumb', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.breadcrumb','data' => []]); ?>
<?php $component->withName('backend.layouts.elements.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('pageHeader', null, []); ?>  Driver  <?php $__env->endSlot(); ?>

            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Driver</li>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

    <div class="card mb-4" style="width:100%">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Driver

            
            <a class="btn btn-sm btn-info" href="<?php echo e(route('drivers.create')); ?>">Add New</a>
            

        </div>
        <div class="card-body">

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.message','data' => ['fmessage' => session('message')]]); ?>
<?php $component->withName('backend.layouts.elements.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['fmessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('message'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.errors','data' => ['errors' => $errors]]); ?>
<?php $component->withName('backend.layouts.elements.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <!-- <table id="datatablesSimple"> -->
            <form method="GET" action="<?php echo e(route('drivers.index')); ?>">

            </form>
             <?php if(is_null($drivers) || empty($drivers)): ?>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <h1 class="text-danger"> <strong>Currently No Information Available!</strong> </h1>
                </div>
            </div>
        <?php else: ?>
            <table class="table" id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Sl#</th>
                        <th>Driver Name</th>
                        <th>Driver Phone</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sl=0 ?>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$sl); ?></td>
                       
                        <td><?php echo e($driver->name); ?></td>
                        
                        <td><?php echo e($driver->phone); ?></td>                      
                        
                        <td>
                            <a class="btn btn-info btn-sm" href="<?php echo e(route('drivers.show', ['driver' => $driver->id])); ?>">Show</a>

                            <a class="btn btn-warning btn-sm" href="<?php echo e(route('drivers.edit', ['driver' => $driver->id])); ?>">Edit</a>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Admin')): ?>
                                
                            <button class="btn btn-sm btn-danger" onclick="deleteDriver(<?php echo $driver->id; ?>)">Delete</button>

                            
                            <?php endif; ?>
                            


                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($drivers->links()); ?>

        </div>
    </div>

    <input type="hidden" value="<?php echo e(url('')); ?>" id="base_url">

    

    <div class="modal" tabindex="-1" id="myModal">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upcoming Trips This Driver Has</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="closeModal()"></button>
            </div>
            <div class="modal-body" id="modal-body">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#SL</th>
                            <th scope="col">Event</th>
                            <th scope="col">Trip Code</th>
                            <th scope="col">Driver</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody id="tbody">
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="closeModal()">Close</button>
                <form method="post" id="deleteForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button onclick="return confirm('Are you sure want to delete ?')" class="btn btn-danger" type="submit">Delete With Trips</button>
                </form>
            </div>
            </div>
        </div>
    </div>

    

    <script>

        const myModal = new bootstrap.Modal(document.getElementById('myModal'), {
            keyboard: true,
        });

        const deleteDriver = (driver_id) => {
            getData(driver_id);
        }

        const getData = (driver_id) => {
            const base_url = $("#base_url").val();
            const fetch_url = `${base_url}/get-trips/by-driver/${driver_id}`;

            fetch(fetch_url)
            .then(response => response.json())
            .then(data => {
                const driver_to_delete = data[1];
                const trips = data[0];
                const drivers = data[2];
                if(trips.length > 0) {
                    openModal(trips, drivers, driver_id)
                } else {
                    if(confirm('Are you sure you want to delete')) {
                        window.location.href = `<?php echo e(URL::to('/driver/delete/${driver_id}')); ?>`;
                    }
                }
            })
        }

        const openModal = (trips, drivers, driver_id) => {  
            myModal.show();

            const deleteForm = document.getElementById('deleteForm');
            const base_url = $("#base_url").val();
            const actionString = `${base_url}/drivers/${driver_id}`;
            deleteForm.action = actionString;

            makeTable(trips, drivers, driver_id);
        }

        const makeTable = (trips, drivers, driver_id) => {
            const tbody = document.getElementById('tbody');
            tbody.innerHTML = '';
            let sl_index = 1;

            trips.map(trip => {
                const tr = document.createElement('tr');

                const sl = document.createElement('td');
                sl.textContent = sl_index;

                const event = document.createElement('td');
                event.textContent = trip['event']['name'];

                const tripCode = document.createElement('td');
                tripCode.textContent = trip['trip_code'];

                const driver = document.createElement('td');

                const selectDiv = document.createElement('div');

                const selectDriver  = document.createElement('select');
                selectDriver.setAttribute('id', `trip-${trip['id']}`);
                selectDriver.setAttribute('class', 'form-control');

                let options = `<option value="">Choose One...</option>`;
                drivers.map(driver => {
                    options += `<option value="${driver['id']}">${driver['name']} - ${driver['license_no']}</option>`;
                })
                selectDriver.innerHTML = options;

                selectDiv.appendChild(selectDriver);
                driver.appendChild(selectDiv)

                const action = document.createElement('td');
                const updateButton = document.createElement('button');
                updateButton.setAttribute('onclick', `updateDriver(${trip['id']}, ${driver_id})`)
                updateButton.setAttribute('class', 'btn btn-sm btn-warning')
                updateButton.textContent = "Update";
                action.appendChild(updateButton);

                tr.append(sl, event, tripCode, driver, action);

                tbody.appendChild(tr);                
            })
        }

        const updateDriver = (trip_id, driver_id) => {
            const selectedDriver = $(`#trip-${trip_id}`).val();

            if(selectedDriver) {
                const base_url = $("#base_url").val();
                const fetch_url = `${base_url}/update-driver/${trip_id}/${selectedDriver}`;

                fetch(fetch_url)
                .then(response => response.json())
                .then(data => {
                    if(data == true) {
                        myModal.hide();
                        getData(driver_id);
                    } else {
                        alert("Something went wrong");
                    }
                });
            } else {
                alert('Please select a driver');
            }
        }

        const closeModal = () => {
            myModal.hide();
        }        
    </script>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/backend/driver/index.blade.php ENDPATH**/ ?>