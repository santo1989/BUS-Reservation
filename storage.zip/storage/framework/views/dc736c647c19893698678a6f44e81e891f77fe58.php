<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.master','data' => []]); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> 
        Edit Trip
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadCrumb', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.breadcrumb','data' => []]); ?>
<?php $component->withName('backend.layouts.elements.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('pageHeader', null, []); ?>  Trip  <?php $__env->endSlot(); ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('trips.index')); ?>">Trip</a></li>
            <li class="breadcrumb-item active">Edit Trip</li>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route('trips.update', ['trip_id' => $trip->id])); ?>" method="post">
        <div>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-6">
                    

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.input','data' => ['name' => 'trip_details','type' => 'textarea','label' => 'Trip Details','value' => ''.e(old('name', $trip->trip_details)).'']]); ?>
<?php $component->withName('backend.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'trip_details','type' => 'textarea','label' => 'Trip Details','value' => ''.e(old('name', $trip->trip_details)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label for="event_id">Event</label>
                    <select name="event_id" id="event_id" class="form-select">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($event->id); ?>"
                                <?php if($event->id == old('name', $trip->event->id)): ?> selected="selected" <?php endif; ?>><?php echo e($event->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.input','data' => ['name' => 'start_date','type' => 'date','label' => 'Start Date','value' => ''.e(old('name', $trip->start_date)).'']]); ?>
<?php $component->withName('backend.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'start_date','type' => 'date','label' => 'Start Date','value' => ''.e(old('name', $trip->start_date)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.input','data' => ['name' => 'end_date','type' => 'date','label' => 'End Date','value' => ''.e(old('name', $trip->end_date)).'']]); ?>
<?php $component->withName('backend.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'end_date','type' => 'date','label' => 'End Date','value' => ''.e(old('name', $trip->end_date)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
                
                

                <div class="col-md-6">

                    <label for="bus_id" >Bus</label>
                    <select name="bus_id" id="bus_id" class="form-select">
                        <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bus->id); ?>"
                                <?php if($bus->id == old('name', $trip->bus->id)): ?> selected="selected" <?php endif; ?>><?php echo e($bus->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="drivers_id" >Driver</label>
                    <select name="drivers_id" id="drivers_id" class="form-select">
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($driver->id); ?>"
                                <?php if($driver->id == old('name', $trip->driver->id)): ?> selected="selected" <?php endif; ?>><?php echo e($driver->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


            </div>
            <div class="form-group mt-3" id="stoppage">
                <?php $__currentLoopData = $trip->stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between align-items-center">
                        <div style="width: 48%;">
                            <label for="stoppages">Stopagges</label>
                            <input name="stoppages[]" class="form-control" id="stoppages" type="text"
                                value=<?php echo e($key); ?>>
                        </div>
                        <div style="width: 48%;">
                            <label for="times">Expected Time</label>
                            <input name="times[]" class="form-control" id="times" type="time"
                                value="<?php echo e($value); ?>">
                        </div>
                        <a class="bg-warning d-flex align-items-center justify-content-center bordered rounded ml-1"
                            style="width: 40px; height: 38px; color: purple; margin-top: 27px;"
                            onclick="createInput()"><i class="fa fa-plus"></i></a>
                        <a class="bg-danger d-flex align-items-center justify-content-center bordered rounded ml-1"
                            style="width: 40px; height: 38px; color: purple; margin-top: 27px;"
                            onclick="deleteDiv(this)"><i class="fa fa-trash"></i></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <button type="submit" class="btn btn-primary" style="margin-left: 33px">Save</button>
        </div>
    </form>

    <script>
        const createInput = () => {
            const parent = document.getElementById("stoppage");
            const div = document.createElement("div");
            div.setAttribute('class', 'd-flex justify-content-between align-items-center');

            const div2 = document.createElement("div");
            div2.setAttribute('style', 'width: 48%;');

            const labelPlace = document.createElement("label");
            labelPlace.setAttribute("for", 'times');
            labelPlace.innerHTML = "pected Time";

            const labelTtime = document.createElement("label");
            labelTtime.setAttribute("for", 'stoppages');
            labelTtime.innerHTML = "Stoppages";

            const inputPlace = document.createElement("input");
            inputPlace.setAttribute("type", "text");
            inputPlace.setAttribute("class", "form-control");
            inputPlace.setAttribute("name", "stoppages[]");

            const inputTime = document.createElement("input");
            inputTime.setAttribute("type", "time");
            inputTime.setAttribute("class", "form-control");
            inputTime.setAttribute("name", "times[]");

            const aPlus = document.createElement("a");
            aPlus.setAttribute("class",
                "bg-warning d-flex align-items-center justify-content-center bordered rounded ml-1");
            aPlus.setAttribute("style", "width: 40px; color: purple");
            aPlus.setAttribute("onclick", "createInput()");

            const iPlus = document.createElement("i");
            iPlus.setAttribute("class", "fa fa-plus");

            const aDelete = document.createElement("a");
            aDelete.setAttribute("class",
                "bg-danger d-flex align-items-center justify-content-center bordered rounded ml-1");
            aDelete.setAttribute("style", "width: 40px; color: black");
            aDelete.setAttribute("onclick", "deleteDiv(this)");

            const iDelete = document.createElement("i");
            iDelete.setAttribute("class", "fa fa-trash");

            parent.appendChild(div);
            parent.appendChild(div2);

            aPlus.appendChild(iPlus);
            aDelete.appendChild(iDelete);
            div.appendChild(inputPlace);
            div.appendChild(inputTime);
            div.appendChild(aPlus);
            div.appendChild(aDelete);

        }

        let deleteDiv = (e) => {
            e.parentNode.remove();
            // console.log(e);
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/backend/trips/edit.blade.php ENDPATH**/ ?>