<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.layouts.master','data' => []]); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.message','data' => ['fmessage' => session('message')]]); ?>
<?php $component->withName('backend.layouts.elements.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['fmessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('message'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Edit Booking</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('updateBooking', ['id' => $booking->id])); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="row">

                                <div class="col-md-6">
                                    <label for="no_of_seat">No of Seat</label>
                                    <input type="number" name="no_of_seat" id="no_of_seat" class="form-control"
                                        value="<?php echo e($booking->no_of_seat); ?>">

                                </div>

                                <div class="col-md-6" id="available_seats">

                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="time_format">Select Time Formate</label>
                                    <select name="time_format" id="time_format" class="form-control" required>
                                        <option value="">Choose One...</option>
                                        <option value="24">24 Hours</option>
                                        <option value="12">12 Hours</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="stoppages">Shuttle Time</label>
                                        <select name="stoppage" id="stoppages" class="form-control">
                                            <?php
                                                // $stoppages = explode(',', $booking->trip->stoppages);
                                                $stoppages = json_decode($booking->trip->stoppages);
                                                
                                                // dd($stoppages);
                                                
                                            ?>
                                            

                                            <?php $__currentLoopData = $stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stoppage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>-<?php echo e($stoppage); ?>"
                                                    <?php echo e($key == $booking->stoppages ? 'selected' : ''); ?>>
                                                    <?php echo e($key); ?>-<?php echo e($stoppage); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>


                            <input type="hidden" name="trip_id" id="trip_id" value="<?php echo e($booking->trip->id); ?>">
                            <br>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        let time_format = document.getElementById("time_format");
        time_format.addEventListener('change', function() {
            console.log(this.value);
            makeStopageTimeformat(this.value);

        });

        function makeStopageTimeformat(time_format) {
            let stoppagesSelectForm = document.getElementById("stoppages");
            let stoppages = <?php echo json_encode($stoppages, true); ?>;
            console.log(stoppages);
            let option = document.createElement('option');
            option = `<option value="">Choose One...</option>`;
            for (stoppage in stoppages) {
                console.log(stoppages[stoppage]);

                let stoppageTime = stoppages[stoppage].split(' ')[0];
                // console.log(stoppageTime);
                let stoppageTimeArray = stoppageTime.split(':');
                // console.log(stoppageTimeArray);
                let hour = stoppageTimeArray[0];
                // console.log(hour);
                let minute = stoppageTimeArray[1];
                // console.log(minute);
                // let second = stoppageTimeArray[2];
                let ampm = stoppages[stoppage].split(' ')[1];
                if (time_format == 24) {
                    //    alert(parseInt(hour) + 12);

                    hour = parseInt(hour) + 12;
                    if(hour == 24){
                        hour = '00';
                    }
                    ampm = '';
                    // let stoppageTimeFormat = hour + ':' + minute + ' ' + ampm;
                    // stoppages.value = stoppageArray[0] + '-' + stoppageTimeFormat;
                }


                option +=
                    `<option value="${stoppage}-${hour}:${minute} ${ampm}">${stoppage}-${hour}:${minute} ${ampm}</option>`;

            }
            stoppagesSelectForm.innerHTML = option;

        }
    </script>
    <script>
        let seat = <?php echo $trip->available_seats; ?>;
        let book_seat = <?php echo $booking->no_of_seat; ?>;
        let seat_old = document.getElementById('no_of_seat');
        let newSeat = document.getElementById('available_seats').innerHTML = " ";
        newSeat = document.getElementById('available_seats').innerHTML =
            ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat}</div>`;

        seat_old.addEventListener('change', function() {
            if (seat_old.value > 0) {
                let seat_new = seat + book_seat - seat_old.value;
                if (seat_new < 0) {
                    alert('Please enter valid number of seats');
                    document.getElementById('available_seats').innerHTML =
                        ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat}</div>`;
                    seat_old.value = book_seat;
                } else {
                    if (seat_new < 6) {
                        newSeat = document.getElementById('available_seats').innerHTML =
                            ` <div class="rounded bg-danger text-white p-2 mt-4">Available Seats: ${seat_new}</div>`;

                    } else {
                        newSeat = document.getElementById('available_seats').innerHTML =
                            ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat_new}</div>`;
                    }
                }
            } else {
                alert('Please enter valid number of seats');
                //   document.getElementById('available_seats').removeChild(p);
                document.getElementById('available_seats').innerHTML =
                    ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat}</div>`;
                seat_old.value = book_seat;
            }


        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/frontend/editbooking.blade.php ENDPATH**/ ?>