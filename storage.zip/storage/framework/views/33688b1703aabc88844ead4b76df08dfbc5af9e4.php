<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.layouts.master','data' => []]); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <?php if(is_null($trips) || empty($trips)): ?>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <h1 class="text-danger"> <strong>Currently No Information Available!</strong> </h1>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">

                    <div class="card m-1 p-1" id="myImg">
                        <img class="card-img-top" src="<?php echo e(asset('images/events/' . $event->images)); ?>" height="300"
                            width="100%" alt="..." />
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card m-1 p-1">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <h3><?php echo e($event->name); ?></h3>

                                </div>


                            </div>

                            <hr>
                            <p><?php echo e($event->details); ?></p>

                        </div>

                    </div>
                </div>

            </div>

            <h3 class="ps-1 mt-3 mb-2 font-weight-bold text-center"><strong>Trips</strong></h3>


            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.errors','data' => ['errors' => $errors]]); ?>
<?php $component->withName('backend.layouts.elements.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <div id="accordion">
                <?php $__empty_1 = true; $__currentLoopData = $event->trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $trip->stoppages = json_decode($trip->stoppages, true);
                    ?>
                    <div class="card mt-2">
                        <div class="card-header d-md-flex justify-content-between" style="background-color: #1f1252"
                            id="heading<?php echo e($trip->id); ?>" data-toggle="collapse"
                            data-target="#collapse<?php echo e($trip->id); ?>"
                            aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                            aria-controls="collapse<?php echo e($trip->id); ?>">
                            <h5 class="mt-1">
                                <p class="btn badge bg-danger">
                                    <?php echo e($trip->trip_code); ?></p>
                            </h5>
                            <h5 class="mt-1">
                                <button class="btn badge bg-info" data-toggle="collapse"
                                    data-target="#collapse<?php echo e($trip->id); ?>"
                                    aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                    aria-controls="collapse<?php echo e($trip->id); ?>">
                                    <i class="fas fa-plane-departure"></i>
                                    <?php echo e(\Carbon\Carbon::parse($trip->start_date)->format('d M, Y')); ?>

                                </button>
                            </h5>
                            <h5 class="mt-1">
                                <p class="btn badge bg-danger"><i class="fas fa-bus"></i> <?php echo e($trip->bus->name); ?>

                                </p>
                            </h5>
                            <h5 class="mt-1">
                                <button class="btn badge bg-info" data-toggle="collapse"
                                    data-target="#collapse<?php echo e($trip->id); ?>"
                                    aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                    aria-controls="collapse<?php echo e($trip->id); ?>">
                                    <i class="fas fa-plane-arrival"></i>
                                    <?php echo e(\Carbon\Carbon::parse($trip->end_date)->format('d M, Y')); ?>

                                </button>
                            </h5>
                        </div>

                        <div id="collapse<?php echo e($trip->id); ?>" class="<?php echo e($index == 0 ? 'collapse show' : 'collapse'); ?>"
                            aria-labelledby="heading<?php echo e($trip->id); ?>" data-parent="#accordion">
                            <div class="card-body">
                                <div class="row border-bottom mt-1 mb-1">
                                    <?php echo e($trip->trip_details); ?>

                                </div>

                                <div class="row">


                                    <div class="col-md-8 col-sm-8">
                                        <ul class="list-group">
                                            <?php $__currentLoopData = $trip->stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item">
                                                    <span><?php echo e($time); ?></span> Shuttle by
                                                    <span><?php echo e($location); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="col-md-4 col-sm-4">
                                        <div class="d-flex justify-content-end w-100">
                                            <button class="btn btn-primary mt-2"
                                                onclick="modalOpen(<?php echo $trip->id; ?>)">Book a
                                                Seat</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class=" text-center">
                        <h3>No Trips Found</h3>
                    </div>
                <?php endif; ?>
            </div>

    </div>

    <?php
        $user_id = session('user')->id ?? '';
    ?>

    <input type="hidden" value="<?php echo e($user_id); ?>" id="user_id">
    <input type="hidden" value="<?php echo e(url('')); ?>" id="base_url">

    
    <div class="modal" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdrop" aria-hidden="false" style=" height: 100vh";>
        <div class="modal-dialog" style="width: 100% !important; height: 100% !important;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Image</h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                </div>

            </div>
        </div>
    </div>
    
    
    <script>
        let images = document.querySelectorAll('.card-img-top');
        let modalBtn = document.querySelector('#modalBtn');
        let modal = document.querySelector('#staticBackdrop');
        let modalBody = document.querySelector('.modal-body');
        let modalTitle = document.querySelector('.modal-title');
        let firstImg = document.querySelector('#myImg');
        let imageShow = document.querySelector('#imageShow');
        let modalImg = document.createElement('img');
        modalImg.setAttribute('height', '95%');
        modalImg.setAttribute('width', '95%');
        modalImg.setAttribute('id', 'modalImg');
        modalBody.appendChild(modalImg);
        images.forEach((image) => {
            image.addEventListener('click', (e) => {
                modalImg.setAttribute('src', e.target.src);
                modalTitle.innerHTML = e.target.alt;
                modal.style.display = 'block';
            });
        });
        modal.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-close')) {
                modal.style.display = 'none';
            }
        });
    </script>
    
    <div class="modal" tabindex="-1" id="booking_modal">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <form action="<?php echo e(route('newBooking')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Book a Seat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-md-4">
                                <label for="name">Name</label>
                                <input class="form-control" type="text" name="name" id="name" required
                                    readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="phone">Phone</label>
                                <input class="form-control" type="text" name="phone" id="phone" required
                                    readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="address">Address</label>
                                <input class="form-control" type="text" name="address" id="address" required
                                    readonly>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-4">
                                <label for="event">Event Name</label>
                                <input class="form-control" type="text" id="event" required readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="trip">Trip Code</label>
                                <input class="form-control" type="text" id="trip" required readonly>
                            </div>

                            <div class="col-md-4">
                                <label for="time_format">Select Time Formate</label>
                                <select name="time_format" id="time_format" class="form-control" required>
                                    <option value="">Choose One...</option>
                                    <option value="24">24 Hours</option>
                                    <option value="12">12 Hours</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label for="stoppage" id="selectnew">Shuttle Place and Time</label>
                                <select name="stoppage" id="stoppage" class="form-control" required>
                                    <option value="">Select One...</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="no_of_seat">Number of Seats</label>
                                <input type="number" class="form-control" id="no_of_seat" name="no_of_seat"
                                    required>
                            </div>
                            <div class="col-md-4" id="available_seats">
                                <div class="rounded bg-success text-white p-2 mt-4">
                                    Available Seats: ${seat}

                                </div>
                            </div>

                        </div>
                        <input type="hidden" name="trip_id" id="trip_id">
                        <input type="hidden" name="passenger_id" id="passenger_id">
                        <input type="hidden" name="event_id" id="event_id">


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Book</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $seat = 0;
            //   dd($seat);
            
            $seat = $trip->available_seats;
            //   dd($seat);
            
            $seat = $seat - $trip->booked_seats;
            //   dd($seat);
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php
            $seat = 0;
        ?>
    <?php endif; ?>
    
    <script>
        const modalOpen = (trip_id) => {
            const user_id = ($("#user_id").val());
            if (user_id.length > 0) {
                const base_url = $("#base_url").val();
                const fethc_url = `${base_url}/get-passenger/${user_id}/${trip_id}`;
                // alert(fethc_url);
                var myModal = new bootstrap.Modal(document.getElementById('booking_modal'), {
                    keyboard: false
                })
                fetch(fethc_url)
                    .then(response => response.json())
                    .then(data => {
                        console.log(Object.keys(data[1]['stoppages']));
                        $("#name").val(data[0]['name']);
                        $("#phone").val(data[0]['phone']);
                        $("#address").val(data[0]['address']);
                        $("#event").val(data[1]['event']['name']);
                        $("#trip").val(data[1]['trip_code']);
                        $("#trip_id").val(data[1]['id']);
                        $("#passenger_id").val(data[0]['id']);
                        $("#event_id").val(data[1]['event_id']);
                        var seats = data[1]['available_seats'];
                        let time_format = document.getElementById("time_format");
                        time_format.addEventListener('change', function() {

                            console.log(this.value);
                            makeStopageTimeformat(this.value);
                        });


                        function makeStopageTimeformat(time_format) {
                            const stoppages = document.getElementById("stoppage");
                            stoppages.innerHTML = "";
                            let options = `<option label="Choose One..." disabled selected></option>`;
                            const locations = Object.keys(data[1]['stoppages']);
                            const times = Object.values(data[1]['stoppages']);
                            const limit = locations.length;
                            const convertTime = timeStr => {
                                const [time, modifier] = timeStr.split(' ');
                                let [hours, minutes] = time.split(':');
                                if (hours === '12') {
                                    hours = '00';
                                }
                                if (modifier === 'PM') {
                                    hours = parseInt(hours, 10) + 12;
                                }
                                return `${hours}:${minutes}`;
                            };
                            for (let i = 0; i < limit; i++) {
                                if (time_format == '12') {

                                    options += `<option value="${locations[i]} - ${times[i]}">${locations[i]} (${times[i]})</option>`;
                                } else {

                                    newtime = convertTime(times[i]);
                                    options += `<option value="${locations[i]} - ${newtime}">${locations[i]} (${newtime})</option>`;
                                }

                            }
                            stoppages.innerHTML = options;
                        }


                        if (seats < 6) {
                            document.getElementById('available_seats').innerHTML =
                                ` <div class="rounded bg-danger text-white p-2 mt-4">Available Seats: ` + seats +
                                `</div>`;
                        } else {
                            document.getElementById('available_seats').innerHTML =
                                ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ` + seats +
                                `</div>`;
                        }

                    })
                myModal.show();
            } else {
                const ans = confirm("You have to log in first. Login now?");
                if (ans == true) {
                    window.location.href = "<?php echo e(URL::to('/passenger-login')); ?>";
                }
            }

        }
    </script>

    <script>
        let seat = <?php echo $seat; ?>;
        let seat_old = document.getElementById('no_of_seat');
        let newSeat = document.getElementById('available_seats').innerHTML = " ";
        newSeat = document.getElementById('available_seats').innerHTML =
            ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat}</div>`;
        seat_old.addEventListener('change', function() {
            if (seat_old.value > 0 && seat_old.value <= seat) {
                let seat_new = seat - seat_old.value;
                if (seat_new < 6) {
                    newSeat = document.getElementById('available_seats').innerHTML =
                        ` <div class="rounded bg-danger text-white p-2 mt-4">Available Seats: ${seat_new}</div>`;
                } else {
                    newSeat = document.getElementById('available_seats').innerHTML =
                        ` <div class="rounded bg-success text-white p-2 mt-4">Available Seats: ${seat_new}</div>`;
                }
            } else {
                alert('Please enter valid number of seats');
                document.getElementById('available_seats').innerHTML = " ";
            }

        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/frontend/events/fleets-details.blade.php ENDPATH**/ ?>