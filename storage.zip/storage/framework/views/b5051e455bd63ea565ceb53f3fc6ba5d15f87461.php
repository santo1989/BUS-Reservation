<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.layouts.master','data' => []]); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <?php if(is_null($events) || empty($events)): ?>
            <div class="row" id="empty">
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <h1 class="text-danger text-center"> <strong>Currently No Information Available!</strong> </h1>
                </div>
            </div>
        <?php else: ?>
            <div>
                
                <div class="mb-5">
                    <form action="#">

                        <div class="input-group mb-3">
                            <input type="text" class="form-control " aria-describedby="button-addon2" name='search'
                                placeholder="Search" />
                            

                        </div>

                    </form>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <div class="col-md-3 col-sm-12 col-xl-3 mb-5" id="card_event">
                        <div class="card h-100">
                            <!-- event image-->
                            
                            <img class="card-img-top" src="<?php echo e(asset('images/events/' . $event->images)); ?>"
                                height="180" alt="..." />
                            <!-- event details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- event name-->
                                    <h5 class="fw-bolder">
                                        <a
                                            href="<?php echo e(route('fleet_details', ['id' => $event->id])); ?>"><?php echo e($event->name); ?></a>
                                    </h5>
                                    <!-- event reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        

                                        <div class="text-muted">
                                            <?php echo e(Str::limit($event->details, 50)); ?>

                                        </div>
                                    </div>
                                    <!-- event price-->
                                </div>
                            </div>
                            <!-- event footer-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <a class="btn btn-outline-warning mt-auto"
                                        href="<?php echo e(route('fleet_details', ['id' => $event->id])); ?>">View Details</a>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <h1 class="text-danger text-center"> <strong>Currently No Information Available!</strong> </h1>
                    </div>
                <?php endif; ?>
            </div>
    </div>
    <script>
        let search = document.querySelector('input[name="search"]');
        let card_event = document.querySelectorAll('#card_event');
        search.addEventListener('keyup', function() {
            let value = search.value.toLowerCase();
            card_event.forEach(function(card) {
                let card_name = card.querySelector('h5').textContent.toLowerCase();
                if (card_name.indexOf(value) != -1) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/frontend/events/fleet.blade.php ENDPATH**/ ?>