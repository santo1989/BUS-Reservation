<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.master','data' => []]); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> 
        Create Trip
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadCrumb', null, []); ?> 
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.breadcrumb','data' => []]); ?>
<?php $component->withName('backend.layouts.elements.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
           <?php $__env->slot('pageHeader', null, []); ?>  Trip  <?php $__env->endSlot(); ?>
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('trips.index')); ?>">Trip</a></li>
          <li class="breadcrumb-item active">Create Trip</li>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('trips.store')); ?>"  method="post">
        <div>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.input','data' => ['name' => 'start_date','type' => 'date','label' => 'Start Date','required' => true]]); ?>
<?php $component->withName('backend.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'start_date','type' => 'date','label' => 'Start Date','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>                
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.input','data' => ['name' => 'end_date','type' => 'date','label' => 'End Date','required' => true]]); ?>
<?php $component->withName('backend.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'end_date','type' => 'date','label' => 'End Date','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>                
                </div>
                
            </div>        
            
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.textarea','data' => ['name' => 'trip_details','label' => 'Trip Details','required' => true]]); ?>
<?php $component->withName('backend.form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'trip_details','label' => 'Trip Details','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <div class="row">        
                <div class=col-md-4>
                    <label for="event_id" class="mt-2">Event</label>
                    <select name="event_id" id="event_id" class="form-select" required>
                        <option value="">Select One...</option>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($event->id); ?>"><?php echo e($event->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class=col-md-4>
                    <label for="bus_id" class="mt-2">Bus</label>
                    <select name="bus_id" id="bus_id" class="form-select" required>
                        <option value="">Select One...</option>
                        <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bus->id); ?>"><?php echo e($bus->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class=col-md-4>
                    <label for="driver_id" class="mt-2">Driver</label>
                    <select name="driver_id" id="driver_id" class="form-select" required>
                        <option value="">Select One...</option>
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group mt-3" id="stoppage">            
                <div class="row">
                    <div class="col-md-6">
                        <label for="stoppages">Shuttle Start Location</label>                    
                        <input name="stoppages[]" class="form-control" id="stoppages" type="text" required>
                    </div>
                    <div class="col-md-5">
                        <label for="times">Expected Time</label>
                        <input name="times[]" class="form-control" id="times" type="time" required>
                    </div>
                    <div class="col-md-1">
                        <a class="bg-warning d-flex align-items-center justify-content-center bordered rounded w-100" style="width: 40px; height: 38px; color: purple; margin-top: 29px;" onclick="createInput()"><i class="fa fa-plus"></i></a>
                    </div>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.form.button','data' => []]); ?>
<?php $component->withName('backend.form.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Save <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>    
        </div>
    </form>
<script>

    const createInput = () => {
        const parent = document.getElementById("stoppage");
        const div = document.createElement("div");
        div.setAttribute('class', 'row g-0 mt-2');

        const div2 = document.createElement("div");
        div2.setAttribute('class', 'col-md-6');

        const div3 = document.createElement("div");
        div3.setAttribute('class', 'col-md-5');        

        const inputPlace = document.createElement("input");
        inputPlace.setAttribute("type", "text");
        inputPlace.setAttribute("class", "form-control");
        inputPlace.setAttribute("name", "stoppages[]");

        const inputTime = document.createElement("input");
        inputTime.setAttribute("type", "time");
        inputTime.setAttribute("class", "form-control");
        inputTime.setAttribute("name", "times[]");

        const aPlus = document.createElement("a");
        aPlus.setAttribute("class", "bg-warning d-flex align-items-center justify-content-center bordered rounded");
        aPlus.setAttribute("style", "width: 40px; color: purple");
        aPlus.setAttribute("onclick", "createInput()");
        
        const iPlus = document.createElement("i");
        iPlus.setAttribute("class", "fa fa-plus");

        const aDelete = document.createElement("a");
        aDelete.setAttribute("class", "bg-danger d-flex align-items-center justify-content-center bordered rounded");
        aDelete.setAttribute("style", "width: 40px; color: black");
        aDelete.setAttribute("onclick", "deleteDiv(this)");

        const btnDiv = document.createElement("div");
        btnDiv.setAttribute("class", "col-md-1 d-flex justify-content-between")
        
        const iDelete = document.createElement("i");
        iDelete.setAttribute("class", "fa fa-trash");

        div2.appendChild(inputPlace);
        div3.appendChild(inputTime);
        div.appendChild(div2);
        div.appendChild(div3);
        aPlus.appendChild(iPlus);
        aDelete.appendChild(iDelete);
        btnDiv.appendChild(aPlus)
        btnDiv.appendChild(aDelete)
        div.appendChild(btnDiv);
        parent.appendChild(div);
    }

    let deleteDiv = (e) => {
        e.parentNode.parentNode.remove();
        

            // console.log(e);
        }
    
        
</script>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/backend/trips/create.blade.php ENDPATH**/ ?>