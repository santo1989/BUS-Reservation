


<img src="<?php echo e(asset('ui/frontend/images/logo_small.png')); ?>" alt="" heigt=100px; width=120px;><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/components/application-logo.blade.php ENDPATH**/ ?>