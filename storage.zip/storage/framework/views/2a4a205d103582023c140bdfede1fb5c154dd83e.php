<button type="submit" class="btn btn-primary">
    <?php echo e($slot); ?>

</button><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/components/backend/form/button.blade.php ENDPATH**/ ?>