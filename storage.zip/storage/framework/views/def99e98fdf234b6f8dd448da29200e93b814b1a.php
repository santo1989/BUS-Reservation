<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.layouts.master','data' => []]); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <?php if(is_null($bookings) || empty($bookings)): ?>
        <div class="row text-center">
            <div class="col-md-12 col-lg-12 col-sm-12" style="height:100vh">
                <h1 class="text-danger text-center"> <strong>You do not have any booking currently!</strong> </h1>
            </div>
        </div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.message','data' => ['fmessage' => session('message')]]); ?>
<?php $component->withName('backend.layouts.elements.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['fmessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('message'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        
        <h3 class="text-center">My Booking</h3>
        

        <div class="table-responsive">
            <table class="table table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>Sl#</th>
                        <th>Trip Date </th>
                        <th>Event Name</th>
                        <th>Trip Name</th>
                        <th>Shuttle Place and Time </th>
                        <th>Booked Seat</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sl=0 ?>
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <tr>
                            <td><?php echo e(++$sl); ?></td>
                            <?php
                                $tripDate = \Carbon\Carbon::parse($booking->trip->trip_date)->format('d-m-Y');
                            ?>
                            <td> <?php echo e($tripDate); ?></td>
                            <td> <?php echo e($booking->event->name); ?></td>
                            <td> <?php echo e($booking->trip->trip_code); ?></td>
                            


                            <td>
                                <?php echo e($booking->stoppage); ?>

                                

                            </td>

                            <td> <?php echo e($booking->no_of_seat); ?></td>
                            <td>
                                <?php
                                    $date = date('d-m-Y');
                                    $tripDate = $booking->trip->start_date;
                                    
                                    $date1 = strtotime($date);
                                    $date2 = strtotime($tripDate);
                                    $diff = abs($date2 - $date1);
                                    $years = floor($diff / (365 * 60 * 60 * 24));
                                    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
                                    $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));
                                    
                                ?>
                                <?php if($days > 0.5): ?>
                                    <a href="<?php echo e(route('editBooking', ['id' => $booking->id])); ?>"
                                        class="btn btn-success">Edit</a>
                                <?php else: ?>
                                <?php endif; ?>
                                <?php if($days > 1): ?>
                                    <form style="display:inline"
                                        action="<?php echo e(route('cancelBooking', ['id' => $booking->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>

                                        <button onclick="return confirm('Are you sure want to delete ?')"
                                            class="btn btn-sm btn-danger" type="submit">Cancel
                                            Booking</button>
                                    </form>
                                <?php else: ?>
                                    <a href="#" class="btn btn-danger" disabled>Time Over</a>
                                <?php endif; ?>





                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No Data Found</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
            
            

        </div>

    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/frontend/myBooking.blade.php ENDPATH**/ ?>