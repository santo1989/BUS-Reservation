<h1 class="mt-4"><?php echo e($pageHeader); ?></h1>
<ol class="breadcrumb mb-4">

    <?php echo e($slot); ?>


</ol><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/components/backend/layouts/elements/breadcrumb.blade.php ENDPATH**/ ?>