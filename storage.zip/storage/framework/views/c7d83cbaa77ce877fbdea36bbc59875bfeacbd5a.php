<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.frontend.layouts.master','data' => []]); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php
    $index = ceil(count($bus->images)/2);
    $featured = explode('. ', $bus->features_details);
    $other_details = explode('. ', $bus->other_details);
  ?>
  <div class="container">
    <div class="row">
      <?php for($i = 0; $i < $index; $i++): ?> 
      <div class="col-md-4 col-sm-4 col-xl-4 mb-1">
        <div class="card">
           <img src="<?php echo e(asset('images/Buses/'.$bus->images[$i])); ?>" class="card-img-top" alt="..." height="200" width="100%">
        </div>
      </div>
      <?php endfor; ?>
    </div>
    <div class="row mt-3">
      <div class="col-md-6 col-sm-12 col-xl-6 mb-1">
        <div class="card">
          <div class="card-header">
            <h4 class="text-center">Features</h4>
          </div>
          <div class="card-body">
            <ul class="list-group">
              <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item"><?php echo e($feature); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        
        </div>
     </div>
      <div class="col-md-6 col-sm-12 col-xl-6">
        <div class="card">
          <div class="card-header">
            <h4 class="text-center">Other Details</h4>
          </div>
          <div class="card-body">
            <ul class="list-group">
              <?php $__currentLoopData = $other_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item"><?php echo e($other_detail); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-3">
      <?php for($i = $index ; $i < count($bus->images); $i++): ?> 
      <div class="col-md-4 col-sm-4 col-xl-4 mb-1">
        <div class="card">
           <img src="<?php echo e(asset('images/Buses/'.$bus->images[$i])); ?>" class="card-img-top" alt="..." height="200" width="100%">
        </div>
      </div>
      <?php endfor; ?>
    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/frontend/transport-details.blade.php ENDPATH**/ ?>