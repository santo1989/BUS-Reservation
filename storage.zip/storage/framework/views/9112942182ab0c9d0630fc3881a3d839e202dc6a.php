<?php $attributes = $attributes->exceptProps(['name', 'label']); ?>
<?php foreach (array_filter((['name', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group">
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <textarea class="form-control" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" rows="3"></textarea>
</div>




<?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/components/backend/form/textarea.blade.php ENDPATH**/ ?>