<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.master','data' => []]); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('pageTitle', null, []); ?> 
     Booking List
   <?php $__env->endSlot(); ?>

   <?php $__env->slot('breadCrumb', null, []); ?> 
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend.layouts.elements.breadcrumb','data' => []]); ?>
<?php $component->withName('backend.layouts.elements.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('pageHeader', null, []); ?>  Booking  <?php $__env->endSlot(); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('bookings.index')); ?>">Booking</a></li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
   <?php $__env->endSlot(); ?>

  <section class="content">
    <div class="container-fluid">
      <?php if(is_null($evs) || empty($evs)): ?>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <h1 class="text-danger"> <strong>Currently No Information Available!</strong> </h1>
                </div>
            </div>
        <?php else: ?>

    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <span class="close" data-dismiss="alert">&times;</span>
        <strong><?php echo e(session('message')); ?>.</strong>
    </div>
    <?php endif; ?>

      <input type="hidden" value="<?php echo e(url('')); ?>" id="base_url">

      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <a class="btn btn-primary" href=<?php echo e(route("bookings.create")); ?>>Create</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div id="accordion">
                <?php $__currentLoopData = $evs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mt-2">
                  <div class="card-header d-flex justify-content-between" id="heading<?php echo e($event->id); ?>">                  
                    <h5 class="mb-0">
                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo e($event->id); ?>" aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($event->id); ?>">
                        <?php echo e($event->name); ?>

                      </button>
                    </h5>
                    <h5 class="mt-1">Total Trip - <?php echo e($event->trip_count); ?></h5>
                  </div>

                  <div id="collapse<?php echo e($event->id); ?>" class="<?php echo e($index == 0 ? 'collapse show' : 'collapse'); ?>" aria-labelledby="heading<?php echo e($event->id); ?>" data-parent="#accordion">
                    <div class="card-body">
                      <table class="table table-dark">
                        <thead>
                          <tr>
                            <th scope="col">Sl</th>
                            <th scope="col">Trip Code</th>
                            <th scope="col">Start Date</th>
                            <th scope="col">End Date</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          
                          <?php $__currentLoopData = $event->trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <th scope="row"><?php echo e($index+1); ?></th>
                              <th><?php echo e($trip->trip_code); ?></th>
                              <td><?php echo e($trip->start_date); ?></td>
                              <td><?php echo e($trip->end_date); ?></td>
                              <td><button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="getBookings(<?php echo $trip->id;  ?>)">Show Bookings</button></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>

  
  <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">          
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-User" id="book_table">
              
              

            </table>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
    

    

    

  <script>
    const getBookings = (trip_id) => {
      const base_url = $('#base_url').val();
      const fethc_url = `${base_url}/get-bookings/${trip_id}`;
      fetch(fethc_url)
      .then(response => response.json())
      .then(data => {console.log(data)
        const { bookings } = data;
        const table = document.getElementById('book_table');
        table.innerHTML = '';
        const thead = document.createElement('thead');
        const tr = document.createElement('tr');
        const th1 = document.createElement('th');
        th1.innerHTML = 'Sl';
        const th2 = document.createElement('th');
        th2.innerHTML = 'Name';
        const th3 = document.createElement('th');
        th3.innerHTML = 'Phone';
        const th4 = document.createElement('th');
        th4.innerHTML = 'Stopage';
        const th5 = document.createElement('th');
        th5.innerHTML = 'No of Seat';
        const th6 = document.createElement('th');
        th6.innerHTML = 'Action';
        tr.append(th1, th2, th3, th4, th5, th6);
        thead.append(tr);
        table.append(thead);
        const tbody = document.createElement('tbody');
     
        data.map((booking, index) => {
          const tr = document.createElement('tr');
          const td1 = document.createElement('td');
          td1.innerHTML = index + 1;
          const td2 = document.createElement('td');
          td2.innerHTML = booking.passenger.name;
          const td3 = document.createElement('td');
          td3.innerHTML = booking.passenger.phone;
          const td4 = document.createElement('td');
          td4.innerHTML = booking.stoppage;
          const td6 = document.createElement('td');
          td6.innerHTML = booking.no_of_seat;
          const td5 = document.createElement('td');
          const a = document.createElement('a');
          a.href = `${base_url}/bookings/edit/${booking.id}`;
          
          a.setAttribute('class', 'btn btn-sm btn-info');
          a.innerHTML = 'Edit';
          
          const deleteForm = document.createElement("form");
          deleteForm.setAttribute('action', `${base_url}/bookings/delete/${booking.id}`);
          deleteForm.setAttribute('method', 'POST');
          deleteForm.innerHTML = 
          `<?php echo csrf_field(); ?>
           <?php echo method_field('delete'); ?>
          `;
          const deleteButton = document.createElement('button');
          deleteButton.setAttribute('type', 'submit');
          deleteButton.setAttribute('class', 'btn btn-sm btn-danger');
          deleteButton.onclick = () => confirm('Are you sure you want to delete this');
          deleteButton.innerHTML = 'Delete';

          deleteForm.appendChild(deleteButton);

          const btnDiv = document.createElement('div');
          btnDiv.setAttribute('class', 'd-flex justify-content-around');

          btnDiv.appendChild(a);
          btnDiv.appendChild(deleteForm);
          
          td5.appendChild(btnDiv);
          tr.append(td1, td2, td3, td4, td6, td5);
          tbody.append(tr);
        });
        table.append(tbody);
        
      });
    }
  </script>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH E:\Programming\www\www\BUS-Reservation\resources\views/backend/bookings/index.blade.php ENDPATH**/ ?>